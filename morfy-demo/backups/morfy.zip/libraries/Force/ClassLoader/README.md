# ClassLoader
The class loader

```php

```


## License
See [LICENSE](https://github.com/force-components/ClassLoader/blob/master/LICENSE)
