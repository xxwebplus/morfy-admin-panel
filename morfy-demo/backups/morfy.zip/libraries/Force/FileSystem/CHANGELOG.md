# v1.0.1, 2015-10-17
* MIT LICENSE instead of GNU GPL v3

# v1.0.0, 2015-10-17
* Initial release
