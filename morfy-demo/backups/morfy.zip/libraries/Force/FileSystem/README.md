# FileSystem
File and Dir class contains methods that assist in working with files and directories.

## License
See [LICENSE](https://github.com/force-components/FileSystem/blob/master/LICENSE)
