# Http
Response and Request class


## License
See [LICENSE](https://github.com/force-components/Http/blob/master/LICENSE)
