# Shortcode
The Shortcode class for creating shortcodes.

## License
See [LICENSE](https://github.com/force-components/Shortcode/blob/master/LICENSE)
