---
title: Welcome  
description: Morfy is a simple and light-weighted Content Management System  
template: index  
---
## Morfy is succesfully installed!  
You can start editing the content and customising your site.

### Edit this Page
To edit this page, simply go to the folder you installed Morfy, and then browse to the `/storage/pages/` folder and open the `index.md` file in your editor.

### Create a New page

Creating a new page is very simple in Morfy.  

1. Launch your text editor and paste this sample text:

    ```
    ---
    title: My New Page
    ---
    My new page body.
    ```

2. Save this file in the `/storage/pages/` folder as `my-new-page.md` and its will be available by this url: http://yoursite/my-new-page

That is it!  

{block name=morfy-docs}
